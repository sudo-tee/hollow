import json
import os
from pathlib import Path
import subprocess

root = Path('/home/francis/Personal/hollow')
out = Path('/tmp/opencode')
agents = {'prior': out / 'hollow-agent-before-bounded-9120249',
          'current': out / 'hollow-agent-after-bounded-9120249'}
env = dict(os.environ)
for key in ('HOLLOW_AGENT_BOUNDED_BULK', 'HOLLOW_AGENT_QUEUE_PROFILE', 'HOLLOW_AGENT_PROFILE', 'HOLLOW_TEST_CONNECTOR_ARGV'):
    env.pop(key, None)
manifest = {'qualification': False, 'scope': 'Software CPU-clock user-space samples for agent and inherited workload only; matching host telemetry enabled to retain perf errors on stderr; not diagnostics-off qualification or kernel/off-CPU profiling.', 'runs': []}
target = out / 'agent-pty-source-perf-manifest-20261018.json'
assert not target.exists()
for round in range(3):
    for variant in (('prior', 'current') if round % 2 == 0 else ('current', 'prior')):
        for workload, size in (('prompt', 10), ('output', 10), ('output', 100)):
            stem = f'agent-pty-source-perf-{round}-{variant}-{workload}-{size}-20261018'
            data = out / (stem + '.data')
            assert not data.exists()
            record = ['perf', 'record', '-q', '-e', 'cpu-clock:u', '-F', '997', '-o', str(data), '--', str(agents[variant]), 'stdio']
            command = ['python3', 'scripts/agent_pty_bench.py', '--agent', str(agents[variant]), '--backend', 'agent', '--telemetry', '--connector-argv', json.dumps(record), '--workload', workload, '--samples', '5000', '--runs', '1', '--size-mib', str(size), '--output', str(out / (stem + '.jsonl'))]
            subprocess.run(command, cwd=root, env=env, check=True)
            report = subprocess.check_output(['perf', 'report', '-i', str(data), '--stdio', '--no-children', '--sort', 'comm,dso,symbol', '--percent-limit', '0.5'], cwd=root, text=True)
            with (out / (stem + '.txt')).open('x') as output:
                output.write(report)
            manifest['runs'].append({'round': round, 'variant': variant, 'workload': workload, 'size_mib': size, 'command': command, 'recording': str(data), 'result': str(out / (stem + '.jsonl')), 'report': str(out / (stem + '.txt'))})
with target.open('x') as output:
    json.dump(manifest, output, indent=2)
    output.write('\n')
